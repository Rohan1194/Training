-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: airline
-- ------------------------------------------------------
-- Server version	5.5.56

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `airport`
--

DROP TABLE IF EXISTS `airport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `airport` (
  `airportcity` varchar(70) NOT NULL,
  `airportcode` varchar(12) NOT NULL,
  `airportname` varchar(70) NOT NULL,
  PRIMARY KEY (`airportcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airport`
--

LOCK TABLES `airport` WRITE;
/*!40000 ALTER TABLE `airport` DISABLE KEYS */;
INSERT INTO `airport` VALUES ('','',''),('Agra','AGR','Agra Air Force Station'),('Agatti','AGX','Agatti Aerodrome'),('airportcity','airportcode','airportname'),('Aizawl','AJL','Lengpui Airport'),('Akola','AKD','Akola Airport'),('Ahmedabad','AMD','Sardar Vallabhbhai Patel International Airport'),('Amritsar','ATQ','Sri Guru Ram Dass Jee International Airport'),('Bhubaneswar','BBI','Biju Patnaik International Airport'),('Vadodara','BDQ','Vadodara Airport'),('Bhuj','BHJ','Bhuj Airport'),('Bhopal','BHO','Raja Bhoj Airport'),('Bhavnagar','BHU','Bhavnagar Airport'),('Bengaluru','BLR','Kempegowda International Airport'),('Brahmapur','BMP','Brahmapur Airport'),('Mumbai','BOM','Chhatrapati Shivaji International Airport'),('Bathinda','BUP','Bathinda Airport'),('Kozhikode','CCJ','Calicut International Airport'),('Kolkata','CCU','Netaji Subhash Chandra Bose International Airport'),('Kadapa','CDP','Kadapa Airport'),('Coimbatore','CJB','Coimbatore International Airport'),('Kochi','COK','Cochin International Airport'),('Dhanbad','DBD','Dhanbad Airport'),('Dehradun','DED','Jolly Grant Airport'),('New Delhi','DEL','Indira Gandhi International Airport'),('Kangra','DHM','Gaggal Airport'),('Dibrugarh','DIB','Dibrugarh Airport'),('Diu','DIU','Diu Airport'),('Dimapur','DMU','Dimapur Airport'),('Guwahati','GAU','Lokpriya Gopinath Bordoloi International Airport'),('Gaya','GAY','Gaya International Airport'),('Goa','GOI','Goa International Airport'),('Gorakhpur','GOP','Gorakhpur Airport'),('Gwalior','GWL','Gwalior airport'),('Hubli','HBX','Hubli Airport'),('Khajuraho','HJR','Khajuraho Airport'),('Hyderadabad','HYD','Rajiv Gandhi International Airport'),('Indore','IDR','Devi Ahilyabai Holkar Airport'),('Imphal','IMF','Imphal International Airport'),('Balasore','IN 0057','Rasgovindpur Airstrip'),('Agartala','IXA','Agartala Airport'),('Siliguri','IXB','Bagdogra Airport'),('Allahabad','IXD','Allahabad Airport'),('Mangalore','IXE','Mangalore International Airport'),('Belgaum','IXG','Belgaum Airport'),('North Lakhimpur','IXI','Lilabari Airport'),('Jammu','IXJ','Jammu Airport'),('Keshod','IXK','Keshod Airport'),('Leh','IXL','Kushok Bakula Rimpochhe Airport'),('Madurai','IXM','Madurai International Airport'),('Ranchi','IXR','Birsa Munda Airport'),('Silchar','IXS','Silchar Airport'),('Pasighat','IXT','Pasighat Airport'),('Aurangabad','IXU','Aurangabad Airport'),('Along','IXV','Along Airport'),('Jamshedpur','IXW','Sonari Airport'),('Kandla','IXY','Kandla Airport'),('Port Blair','IXZ','Veer Savarkar International Airport'),('Jaipur','JAI','Jaipur International Airport'),('Jodhpur','JDH','Jodhpur Airport'),('Jamnagar','JGA','Jamnagar Airport'),('Jabalpur','JLR','Jabalpur Airport'),('Jorhat','JRH','Jorhat Airport'),('Jharsuguda','JSA','Jharsuguda Airport'),('Imphal','KG','Koirengei Airstrip Airport'),('Kolhapur','KLH','Kolhapur Airport'),('Kanpur','KNU','Kanpur Airport'),('Kullu','KUU','Bhuntar Airport'),('Lucknow','LKO','Chaudhary Charan Singh International Airport'),('Chennai','MAA','Chennai International Airport'),('Mysore','MYQ','Mysore Airport'),('Nagpur','NAG','Dr. Babasaheb Ambedkar International Airport'),('Patna','PAT','Jay Prakash Narayan International Airport'),('Porbandar','PBD','Porbandar Airport'),('Pantnagar','PGH','Pantnagar Airport'),('','PNQ','Pune Airport'),('Pathankot','PTK','Pathankot Airport'),('Jeypore','PYB','Jeypore Airport'),('Rajkot','RAJ','Rajkot Airport'),('Rajahmundry','RJA','Rajahmundry Airport'),('Raipur','RPR','Swami Vivekananda Airport'),('r','rr','Ranchi'),('Raxaul','RXL','Raxaul Airport'),('Shillong','SHL','Shillong Airport'),('Shimla','SLV','Shimla Airport'),('Solapur','SSL','Solapur Airport'),('Surat','STV','Surat Airport'),('Srinagar','SXR','Srinagar International Airport'),('Tuticorin','TCR','Tuticorin Airport'),('Tezpur','TEZ','Tezpur Airport'),('Tirupati','TIR','Tirupati Airport'),('Satna','TNI','Satna Airport'),('Tura','TRU','Baljek Airport'),('Trivandrum','TRV','Trivandrum International Airport'),('Tiruchirapalli','TRZ','Tiruchirapalli International Airport'),('Udaipur','UDR','Maharana Pratap Airport'),('Vijayawada','VGA','Vijayawada International Airport'),('Varanasi','VNS','Lal Bahadur Shastri Airport'),('Visakhapatnam','VTZ','Visakhapatnam Airport');
/*!40000 ALTER TABLE `airport` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-25 15:46:56
